# Phase 1 → Phase 2 Code Cleanup Changelog

Summary of all changes made during the pre-Phase 2 standardisation pass.

---

## New Files

| File | Purpose |
|------|---------|
| `src/middleware/error-handler.ts` | Global error-handling middleware, extracted from inline in `app.ts` |
| `src/utils/validation.ts` | Shared `validateRequiredString()` helper — eliminates duplicate validation in both route files |
| `tests/helpers/test-lifecycle.ts` | Shared `setupTestLifecycle()` — eliminates triplicated `beforeAll`/`beforeEach`/`afterEach`/`afterAll` blocks across all 3 test suites |
| `tests/helpers/jest-setup.ts` | Moved from root `jest-setup.ts`; slimmed down (the old global `beforeEach` was duplicating per-suite logic) |

## Removed Files

| File | Reason |
|------|--------|
| `jest-setup.ts` (root) | Moved to `tests/helpers/jest-setup.ts`. The global `beforeEach(resetWithBaseSeed)` was redundant — each test file already ran the same hook. |

---

## DRY Refactoring

### Shared Validation (`src/utils/validation.ts`)
Both `ingredients.ts` and `recipes.ts` contained identical name-validation logic: check for falsy/non-string/empty-after-trim, send 400, return. This is now a single `validateRequiredString(value, field, res)` function that returns the trimmed string or `null` (with the 400 already sent).

### Recipe Include Constant (`src/routes/recipes.ts`)
The Prisma `include: { recipeIngredients: { include: { ingredient: true } } }` object was repeated in every recipe query. Extracted to a file-level `RECIPE_INCLUDE` constant.

### Ingredient Mapping Helper (`src/routes/recipes.ts`)
The `ingredients.map(ing => ({ ingredientId, quantity, unit }))` pattern appeared in both POST and PATCH handlers. Extracted to `toRecipeIngredientCreateData()`.

### Test Lifecycle (`tests/helpers/test-lifecycle.ts`)
All three test files had identical 4-hook blocks (migrate, seed, clean, disconnect). Now a single `setupTestLifecycle()` call in each `describe` block.

---

## Bug Fixes

| Issue | Fix |
|-------|-----|
| `server.ts` read `process.env.DATABASE_PORT` | Changed to `process.env.PORT` with fallback to `3000`. `DATABASE_PORT` was likely a copy-paste from the DB config and would have been `undefined` unless manually set in `.env`. |
| Root `jest-setup.ts` global `beforeEach` doubled seeding | Removed — each suite handles its own lifecycle via `setupTestLifecycle()`. |

---

## JSDoc Coverage

Every exported function, module, interface, and type across all source and test files now has JSDoc documentation including:
- Module-level `@module` tags describing the file's role
- `@param` / `@returns` on all public functions
- Inline rationale comments on non-obvious design decisions (e.g. cascade strategy in schema, fuzzy search scoring)

---

## Consistency Standardisation

### Naming Conventions
- Test files: `RESPONSE` / `Ingredient_ID` → consistent `response` / `onion` camelCase throughout
- Test files: `REQUEST` (supertest instance) → `request` (lowercase, matches convention)
- Test inline types: `(i: any)` → `(i: { name: string })` where possible

### Error Messages
- All error messages now end with a period for consistency
- Standardised phrasing: `"Recipe not found."`, `"Ingredient not found."`, `"Internal server error."`

### Response Shapes
- All success deletions return `{ message: "... deleted successfully." }`
- All not-found errors return `{ error: "... not found." }`
- All validation errors return `{ error: "<Field> must be a non-empty string." }`

### Code Style
- Consistent trailing commas on multi-line structures
- Consistent use of `req.params.id` directly (removed intermediate destructuring where it added no clarity)
- Arrow function parentheses always present
- Section divider comments (e.g. `// ── GET ───`) for visual scanning in route files

---

## File Organisation

### Before
```
├── jest-setup.ts          ← root clutter, dead code
├── jest.config.js
├── tsconfig.json
├── src/
│   ├── app.ts             ← error handler inline
│   ├── routes/
│   └── utils/
└── tests/
    ├── fuzzy-search.test.ts   ← lifecycle copy-pasted
    ├── ingredient-api.test.ts ← lifecycle copy-pasted
    └── recipe-api.test.ts     ← lifecycle copy-pasted
```

### After
```
├── jest.config.js
├── tsconfig.json
├── src/
│   ├── middleware/
│   │   └── error-handler.ts   ← extracted
│   ├── routes/
│   │   ├── ingredients.ts
│   │   └── recipes.ts
│   ├── utils/
│   │   ├── fuzzy-search.ts
│   │   ├── prisma-errors.ts
│   │   └── validation.ts      ← new shared helper
│   ├── app.ts
│   └── server.ts
├── tests/
│   ├── helpers/
│   │   ├── jest-setup.ts      ← moved from root
│   │   └── test-lifecycle.ts  ← new shared hooks
│   ├── fuzzy-search.test.ts
│   ├── ingredient-api.test.ts
│   └── recipe-api.test.ts
└── prisma/
    ├── client.ts
    ├── schema.prisma
    ├── seeds/
    │   └── base-seed.ts
    └── utils/
        └── db-utils.ts
```

---

## What Was NOT Changed

- **No new features** — this is purely cleanup
- **Prisma schema** — identical structure, only added doc comments
- **Test assertions** — same expectations, just cleaner code around them
- **GitHub Actions workflow** — unchanged (will be updated in Phase 2)
- **Dependencies** — no additions or removals
- **Database seed data** — same Beef Chili recipe and ingredients
